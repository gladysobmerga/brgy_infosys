
  # Barangay Medicine Information System

  This is a code bundle for Barangay Medicine Information System. The original project is available at https://www.figma.com/design/mqLG0c2d5VFAG8pq1Ws1o4/Barangay-Medicine-Information-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  